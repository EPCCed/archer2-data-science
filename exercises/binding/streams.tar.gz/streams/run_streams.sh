#!/bin/bash
#SBATCH -o streams.%A.out
#SBATCH -e streams.%A.err
#SBATCH -J streams
#SBATCH --nodes=1
#SBATCH --tasks-per-node=128
#SBATCH --cpus-per-task=1
#SBATCH --time=0:10:0
#SBATCH --partition=standard
#SBATCH --qos=short

NODES=1
CORES_PER_NODE=128
TOTAL_CORES=$((NODES*CORES_PER_NODE))
THREADS=1
PROCESSES=0
PPN=0

for THREADS in 1;
do
  export OMP_NUM_THREADS=$THREADS
  srun --distribution=block:block ./distributed_streams 

done


