#!/bin/bash

#SBATCH -o ior.%A.out
#SBATCH -e ior.%A.err
#SBATCH -J ior
#SBATCH --nodes=1
#SBATCH --tasks-per-node=128
#SBATCH --cpus-per-task=1
#SBATCH --time=0:10:0
#SBATCH --partition=standard
#SBATCH --qos=short


mkdir data

srun src/C/IOR -vvv -b 2g -f test.script.easy

rm -fr data

mkdir data

srun src/C/IOR -vvv -b 2g -f test.script.hard

rm -fr data


