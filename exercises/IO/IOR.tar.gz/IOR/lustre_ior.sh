#!/bin/bash

#SBATCH -o ior.%A.out
#SBATCH -e ior.%A.err
#SBATCH -J ior
#SBATCH --nodes=2
#SBATCH --tasks-per-node=128
#SBATCH --cpus-per-task=1
#SBATCH --time=0:20:0
#SBATCH --partition=standard
#SBATCH --qos=short

rm -fr data

mkdir data

srun src/C/IOR -vvv -C -b 512mb -f test.script.easy

rm -fr data

mkdir data

srun src/C/IOR -vvv -C -b 512mb -f test.script.hard

rm -fr data


